//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by LampServer.rc
//
#define IDD_ABOUTBOX                    100
#define IDD_LAMPSERVER_FORM             101
#define IDP_SOCKETS_INIT_FAILED         104
#define IDR_MAINFRAME                   128
#define IDR_LAMPSETYPE                  129
#define IDD_DIALOG_LOGIN                130
#define IDC_EDIT1                       1000
#define IDC_EDIT2                       1001
#define IDC_BUTTON1                     1002
#define IDC_BUTTON2                     1003
#define IDC_BUTTON3                     1004

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1003
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
