//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by baidumap.rc
//
#define IDD_BAIDUMAP_DIALOG             102
#define IDR_MAINFRAME                   128
#define IDR_MENU1                       132
#define IDR_MENU2                       133
#define IDD_DIALOG1                     134
#define IDB_BITMAP1                     135
#define IDR_MENU3                       136
#define IDD_DIALOG2                     137
#define IDD_DIALOG3                     139
#define IDB_BITMAP2                     140
#define IDD_DIALOG4                     141
#define IDD_DIALOG5                     142
#define IDC_EXPLORER1                   1000
#define IDC_BUTTON1                     1001
#define IDC_EDIT1                       1002
#define IDC_EDIT2                       1003
#define IDC_LIST1                       1008
#define IDC_LIST2                       1009
#define IDC_COMBO1                      1010
#define IDC_EDIT3                       1011
#define IDC_EDIT4                       1012
#define IDC_EDIT5                       1013
#define IDC_LIST3                       1014
#define IDC_SLIDER2                     1016
#define ID_MENUITEM32773                32773
#define ID_MENUITEM32774                32774
#define ID_MENUITEM32775                32775
#define ID_MENUITEM32776                32776
#define ID_MENUITEM32777                32777
#define ID_MENUITEM32780                32780
#define ID_MENUITEM32781                32781
#define ID_MENUITEM32784                32784
#define ID_MENUITEM32785                32785
#define ID_MENUITEM32786                32786
#define ID_MENUITEM32788                32788
#define ID_MENUITEM32789                32789
#define ID_MENUITEM32790                32790
#define ID_MENUITEM32791                32791
#define ID_MENUITEM32792                32792
#define ID_MENUITEM32794                32794
#define ID_MENUITEM32795                32795
#define ID_MENUITEM32796                32796
#define ID_MENUITEM32797                32797
#define ID_MENUITEM32798                32798
#define ID_MENUITEM32799                32799
#define ID_MENUITEM32800                32800
#define ID_MENUITEM32802                32802

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        143
#define _APS_NEXT_COMMAND_VALUE         32803
#define _APS_NEXT_CONTROL_VALUE         1018
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
